/* srcs/main.c */
#include "../includes/push_swap.h"

/* srcs/main.c */
#include "push_swap.h"

static void ft_init_config(t_config *config)
{
    config->has_bench = 0;
    config->strategy = 3; // Default: Adaptive
    config->ops.sa = 0;
    config->ops.sb = 0;
    config->ops.ss = 0;
    config->ops.pa = 0;
    config->ops.pb = 0;
    config->ops.ra = 0;
    config->ops.rb = 0;
    config->ops.rr = 0;
    config->ops.rra = 0;
    config->ops.rrb = 0;
    config->ops.rrr = 0;
    config->ops.total = 0;
}

int main(int argc, char **argv)
{
    t_node      *a;
    t_node      *b;
    t_config    cfg;
    double      dis;

    if (argc < 2)
        return (0);
    ft_init_config(&cfg);
    a = ft_parse_args(argc, argv, &cfg);
    b = NULL;
    dis = compute_disorder(a);
    if (ft_node_size(a) > 5)
    {
        ft_index_stack(a);
        ft_execute_strategy(&a, &b, &cfg, dis);
    }
    else
        simple_sort(&a, &b, &cfg);
    if (cfg.has_bench)
        ft_print_bench(&cfg, dis, get_strategy_name(cfg.strategy));
    ft_free_stack(&a);
    ft_free_stack(&b);
    return (0);
}