/* srcs/algorithms/index.c */
#include "../../includes/push_swap.h"

void    ft_index_stack(t_node *a)
{
    t_node  *current;
    t_node  *compare;
    int     count;

    if (!a)
        return ;
    current = a;
    while (current)
    {
        count = 0;
        compare = a;
        while (compare)
        {
            // Compara os valores originais sem corrompê-los no meio do loop
            if (compare->value < current->value)
                count++;
            compare = compare->next;
        }
        current->index = count; // Salva o rank no index, mantendo o value intacto
        current = current->next;
    }
}