#include "../../includes/push_swap.h"

void simple_sort(t_node **a, t_node **b, t_config *config)
{
    int size;
    
    if (!a || !*a || is_sorted(*a))
        return ;
    size = ft_node_size(*a);
    if (size == 2)
    {
        if ((*a)->value > (*a)->next->value)
            ft_sa(a, config);
        return ;
    }
    if (size == 3)
    {
        sort_three(a, config);
        return ;
    }
    while (ft_node_size(*a) > 3)
    {
        move_min_to_top(a, config);
        ft_pb(a, b, config);
    }
    sort_three(a, config);
    while (ft_node_size(*b) > 0)
        ft_pa(a, b, config);
}

void sort_three(t_node **a, t_config *config)
{
    int first;
    int second;
    int third;

    if (!a || !*a || !(*a)->next || !(*a)->next->next)
        return ;
    first = (*a)->value;
    second = (*a)->next->value;
    third = (*a)->next->next->value;
    if (first > second && first > third)
    {
        ft_ra(a, config);
        if (second > third)
            ft_sa(a, config);
    }
    else if (second > first && second > third)
    {
        ft_rra(a, config);
        if (first < third)
            ft_sa(a, config);
    }
    else if (first > second)
        ft_sa(a, config);
}
static int get_min_position(t_node *a)
{
    int     min_val;
    int     min_pos;
    int     current_pos;
    t_node *tmp;

    min_val = a->value;
    min_pos = 0;
    current_pos = 0;
    tmp = a;
    while (tmp)
    {
        if (tmp->value < min_val)
        {
            min_val = tmp->value;
            min_pos = current_pos;
        }
        tmp = tmp->next;
        current_pos++;
    }
    return (min_pos);
}

void move_min_to_top(t_node **a, t_config *config)
{
    int min_pos;
    int size;

    if (!a || !*a)
        return ;
    min_pos = get_min_position(*a);
    size = ft_node_size(*a);
    if (min_pos <= size / 2)
    {
        while (min_pos > 0)
        {
            ft_ra(a, config);
            min_pos--;
        }
    }
    else
    {
        while (min_pos < size)
        {
            ft_rra(a, config);
            min_pos++;
        }
    }
}
int is_sorted(t_node *stack)
{
    if (!stack)
        return (1);
    while (stack && stack->next)
    {
        if (stack->value > stack->next->value)
            return (0);
        stack = stack->next;
    }
    return (1);
}