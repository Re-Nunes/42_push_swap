/* srcs/algorithms/bucket_sort.c */
#include "../../includes/push_swap.h"

void	ft_bucket_sort(t_node **a, t_node **b, t_config *config)
{
	int	size;
	int	pushed;

	size = ft_node_size(*a);
	pushed = 0;
	while (*a && size > 3)
	{
		if (pushed < size / 2)
		{
			ft_pb(a, b, config);
			pushed++;
		}
		else
		{
			ft_ra(a, config);
		}
	}
	while (*b)
		ft_pa(a, b, config);
}
