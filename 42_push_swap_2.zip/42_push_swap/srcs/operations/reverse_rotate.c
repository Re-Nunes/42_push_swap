/* srcs/operations/reverse_rotate.c */
#include "../../includes/push_swap.h"

static void do_reverse_rotate(t_node **stack)
{
    t_node  *first;
    t_node  *last;

    if (!stack || !*stack || !(*stack)->next)
        return ;
    first = *stack;
    last = first;
    while (last->next)
        last = last->next;
    last->prev->next = NULL;
    last->prev = NULL;
    last->next = first;
    first->prev = last;
    *stack = last;
}

void    ft_rra(t_node **a, t_config *config)
{
    do_reverse_rotate(a);
    ft_putstr_fd("rra\n", 1); // Imprime sempre na stdout (1)
    if (config)
    {
        config->ops.rra++;
        config->ops.total++;
    }
}

void    ft_rrb(t_node **b, t_config *config)
{
    do_reverse_rotate(b);
    ft_putstr_fd("rrb\n", 1); // Imprime sempre na stdout (1)
    if (config)
    {
        config->ops.rrb++;
        config->ops.total++;
    }
}

void    ft_rrr(t_node **a, t_node **b, t_config *config)
{
    do_reverse_rotate(a);
    do_reverse_rotate(b);
    ft_putstr_fd("rrr\n", 1); // Imprime sempre na stdout (1)
    if (config)
    {
        config->ops.rrr++;
        config->ops.total++;
    }
}