/* srcs/operations/swap.c */
#include "../../includes/push_swap.h"

static void do_swap(t_node **stack)
{
    t_node *first;
    t_node *second;

    if (!stack || !*stack || !(*stack)->next)
        return ;
    first = *stack;
    second = (*stack)->next;
    first->next = second->next;
    if (second->next)
        second->next->prev = first;
    second->prev = NULL;
    second->next = first;
    first->prev = second;
    *stack = second;
}

void ft_sa(t_node **a, t_config *config)
{
    do_swap(a);
    ft_putstr_fd("sa\n", 1);
    if (config)
    {
        config->ops.sa++;
        config->ops.total++;
    }
}

void    ft_sb(t_node **b, t_config *config)
{
    do_swap(b);
    ft_putstr_fd("sb\n", 1);
    if (config)
    {
        config->ops.sb++;
        config->ops.total++;
    }
}

void    ft_ss(t_node **a, t_node **b, t_config *config)
{
    do_swap(a);
    do_swap(b);
    ft_putstr_fd("ss\n", 1);
    if (config)
    {
        config->ops.ss++;
        config->ops.total++;
    }
}