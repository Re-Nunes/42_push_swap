/* srcs/operations/push.c */
#include "../../includes/push_swap.h"

static void do_push(t_node **dest, t_node **src)
{
    t_node  *tmp;

    if (!src || !*src)
        return ;
    tmp = *src;
    *src = (*src)->next;
    if (*src)
        (*src)->prev = NULL;
    tmp->next = *dest;
    if (*dest)
        (*dest)->prev = tmp;
    tmp->prev = NULL;
    *dest = tmp;
}

void    ft_pa(t_node **a, t_node **b, t_config *config)
{
    do_push(a, b);
    ft_putstr_fd("pa\n", 1); // Imprime sempre!
    if (config)
    {
        config->ops.pa++;
        config->ops.total++;
    }
}

void    ft_pb(t_node **a, t_node **b, t_config *config)
{
    do_push(b, a);
    ft_putstr_fd("pb\n", 1); // Imprime sempre!
    if (config)
    {
        config->ops.pb++;
        config->ops.total++;
    }
}
