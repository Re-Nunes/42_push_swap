/* srcs/operations/rotate.c */
#include "../../includes/push_swap.h"

static void do_rotate(t_node **stack)
{
    t_node  *first;
    t_node  *last;

    if (!stack || !*stack || !(*stack)->next)
        return ;
    first = *stack;
    last = first;
    while (last->next)
        last = last->next;
    *stack = first->next;
    (*stack)->prev = NULL;
    first->next = NULL;
    first->prev = last;
    last->next = first;
}

void    ft_ra(t_node **a, t_config *config)
{
    do_rotate(a);
    ft_putstr_fd("ra\n", 1); // Imprime sempre na stdout (1)
    if (config)
    {
        config->ops.ra++;
        config->ops.total++;
    }
}

void    ft_rb(t_node **b, t_config *config)
{
    do_rotate(b);
    ft_putstr_fd("rb\n", 1); // Imprime sempre na stdout (1)
    if (config)
    {
        config->ops.rb++;
        config->ops.total++;
    }
}

void    ft_rr(t_node **a, t_node **b, t_config *config)
{
    do_rotate(a);
    do_rotate(b);
    ft_putstr_fd("rr\n", 1); // Imprime sempre na stdout (1)
    if (config)
    {
        config->ops.rr++;
        config->ops.total++;
    }
}