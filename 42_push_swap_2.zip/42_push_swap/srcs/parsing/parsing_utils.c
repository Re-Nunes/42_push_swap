#include "../../includes/push_swap.h"

int	ft_strcmp(char *str1, char *str2)
{
	int	i;

	i = 0;
	while (str1[i] && str2[i] && str1[i] == str2[i])
		i++;
	return ((unsigned char)str1[i] - (unsigned char)str2[i]);
}

int	ft_parse_flag(char *arg, t_config *config)
{
	if (ft_strcmp(arg, "--simple") == 0)
		config->strategy = 0;
	else if (ft_strcmp(arg, "--medium") == 0)
		config->strategy = 1;
	else if (ft_strcmp(arg, "--complex") == 0)
		config->strategy = 2;
	else if (ft_strcmp(arg, "--adaptive") == 0)
		config->strategy = 3;
	else if (ft_strcmp(arg, "--bench") == 0)
		config->has_bench = 1;
	else
		return (0);
	return (1);
}

void ft_parse_split(char *arg, t_node **a, t_config *config)
{
    char    **split;
    int     j;
    int     error;

    if (ft_parse_flag(arg, config))
        return ;
    split = ft_split(arg, ' ');
    if (!split || !split[0])
        ft_error_exit(a, split);
    j = 0;
    while (split[j])
    {
        if (!ft_is_digit_str(split[j]))
            ft_error_exit(a, split);
        error = 0;
        ft_add_back(a, ft_create_node((int)ft_atoll(split[j], &error)));
        if (error)
            ft_error_exit(a, split);
        j++;
    }
    ft_free_split(split);
}
