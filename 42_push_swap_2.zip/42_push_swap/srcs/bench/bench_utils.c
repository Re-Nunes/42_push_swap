#include "../../includes/push_swap.h"

#include "push_swap.h"

static void ft_print_ops_pt1(t_config *cfg)
{
    ft_putstr_fd("[bench] sa: ", 2);
    ft_putnbr_fd(cfg->ops.sa, 2);
    ft_putstr_fd(" sb: ", 2);
    ft_putnbr_fd(cfg->ops.sb, 2);
    ft_putstr_fd(" ss: ", 2);
    ft_putnbr_fd(cfg->ops.ss, 2);
    ft_putstr_fd(" pa: ", 2);
    ft_putnbr_fd(cfg->ops.pa, 2);
    ft_putstr_fd(" pb: ", 2);
    ft_putnbr_fd(cfg->ops.pb, 2);
    ft_putstr_fd("\n[bench] ra: ", 2);
    ft_putnbr_fd(cfg->ops.ra, 2);
    ft_putstr_fd(" rb: ", 2);
    ft_putnbr_fd(cfg->ops.rb, 2);
    ft_putstr_fd(" rr: ", 2);
    ft_putnbr_fd(cfg->ops.rr, 2);
    ft_putstr_fd("\n", 2);
}

static void ft_print_ops_pt2(t_config *cfg)
{
    ft_putstr_fd("[bench] rra: ", 2);
    ft_putnbr_fd(cfg->ops.rra, 2);
    ft_putstr_fd(" rrb: ", 2);
    ft_putnbr_fd(cfg->ops.rrb, 2);
    ft_putstr_fd(" rrr: ", 2);
    ft_putnbr_fd(cfg->ops.rrr, 2);
    ft_putstr_fd("\n", 2);
}

char *get_strategy_name(int strategy)
{
    if (strategy == 0)
        return ("Simple / O(n^2)");
    else if (strategy == 1)
        return ("Medium / O(n sqrt(n))");
    else if (strategy == 2)
        return ("Complex / O(n log n)");
    return ("Adaptive / O(n sqrt(n))");
}

void ft_print_bench(t_config *config, double disorder, char *strat)
{
    int ip;
    int dp;

    ip = (int)(disorder * 100);
    dp = (int)(disorder * 10000) % 100;
    ft_putstr_fd("[bench] disorder: ", 2);
    ft_putnbr_fd(ip, 2);
    ft_putstr_fd(".", 2);
    if (dp < 10)
        ft_putstr_fd("0", 2);
    ft_putnbr_fd(dp, 2);
    ft_putstr_fd("%\n[bench] strategy: ", 2);
    ft_putstr_fd(strat, 2);
    ft_putstr_fd("\n[bench] total_ops: ", 2);
    ft_putnbr_fd(config->ops.total, 2);
    ft_putstr_fd("\n", 2);
    ft_print_ops_pt1(config);
    ft_print_ops_pt2(config);
}