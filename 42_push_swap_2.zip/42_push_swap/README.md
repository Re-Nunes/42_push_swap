*This project has been created as part of the 42 curriculum by renatanu, jonathfe*

*This project has been created as part of the 42 curriculum by renatanu, jonathfe*

## Descrição

O **Push Swap** é um projeto de ordenação cujo objetivo é ordenar uma pilha de números inteiros utilizando um conjunto limitado de operações em duas pilhas, minimizando ao mesmo tempo o número de movimentos. O desafio não é apenas realizar a ordenação corretamente, mas fazê-lo de forma eficiente o suficiente para atender às exigências do currículo da 42.

O projeto é implementado em C e utiliza uma lista duplamente encadeada personalizada como estrutura de dados subjacente para as pilhas. O programa recebe uma lista de números inteiros como entrada, organiza-os na pilha A e, em seguida, move elementos entre a pilha A e a pilha B utilizando apenas operações como `sa`, `sb`, `pa`, `pb`, `ra`, `rb`, `rra`, `rrb` e suas variantes combinadas.

### Objetivos do projeto
O objetivo principal é alcançar um estado final no qual a pilha A contenha os números em ordem crescente e a pilha B esteja vazia.

- Ordenar números inteiros com o menor número possível de operações de pilha
- Utilizar apenas um conjunto restrito de instruções
- Implementar código em C eficiente e legível
- Respeitar restrições de memória e desempenho
- Fornecer uma seleção de algoritmos funcional, com base no tamanho da entrada e no nível de desordem

## Instruções
#### Requisitos

- Um ambiente do tipo Unix
- `make`
- Um compilador C, como o `cc`

### Compilação
A partir da raiz do projeto:

```c
make
#### Requisitos

- Um ambiente do tipo Unix
- make
- Um compilador C, como o cc

### Compilação
A partir da raiz do projeto:

``` C
make
```
Isso compila o projeto e gera o executável chamado push_swap.

**Execução**

``` C
./push_swap 3 2 1 5 4
```

Você também pode forçar um modo de algoritmo específico:

``` C
./push_swap --simple 3 2 1
./push_swap --medium 8 7 6 5 4 3 2 1
./push_swap --complex 10 9 8 7 6 5 4 3 2 1
./push_swap --bench 4 67 3 87 23
```

Se nenhum modo for especificado, o programa escolhe automaticamente uma abordagem com base no nível de desordem e no tamanho da pilha.

#### Tratamento de erros
O programa exibe:

``` C
Error
```
quando a entrada é inválida — por exemplo, se um número estiver mal formatado, ultrapassar os limites de um inteiro ou houver duplicatas.

### Seleção e Justificativa de Algoritmos

Este projeto inclui várias estratégias para lidar com diferentes tamanhos de entrada e níveis de desordem. O objetivo é escolher o método mais eficiente de acordo com a situação, em vez de usar um único algoritmo para tudo.

#### 1. Estratégia para pilhas pequenas
Para pilhas muito pequenas — especialmente com 2 ou 3 elementos —, o programa utiliza uma lógica de ordenação manual direta e altamente otimizada. Essa é a abordagem mais eficiente, pois esses casos são pequenos demais para se beneficiarem de manipulações de pilha mais complexas.

A lógica verifica as possíveis disposições de 2 ou 3 elementos e aplica o mínimo necessário de operações de troca ou rotação. Essa abordagem reduz a sobrecarga (overhead) e mantém o número total de instruções extremamente baixo para casos triviais.

#### 2. Estratégia intermediária
Para entradas de tamanho médio, este projeto utiliza uma abordagem intermediária baseada em particionamento de pilha. A ideia é reduzir o problema de ordenação a partes menores e mais gerenciáveis, movendo valores para a pilha B de forma estruturada e, em seguida, restaurando-os para a pilha A na ordem correta.

Essa abordagem é atraente porque:

- Evita comparações repetidas de toda a sequência

- Oferece um excelente equilíbrio entre velocidade de execução e complexidade de implementação

Neste projeto, a opção `--medium` é direcionada para a mesma lógica orientada a *radix* usada para a reorganização eficiente da pilha, mantendo ao mesmo tempo a estratégia alternativa para pilhas pequenas em casos triviais.

#### 3. Estratégia complexa / *radix* completo
Para entradas maiores e mais desordenadas, o projeto utiliza um método de ordenação baseado em radix bit a bit. O radix sort é muito adequado aqui porque não exige comparações custosas entre todos os elementos da pilha; em vez disso, organiza os números com base em sua representação binária.Isso é especialmente útil para um projeto como o Push Swap porque:

- Aproveita o fato de os números estarem indexados como inteiros
- A abordagem bit a bit reduz drasticamente o número de operações de movimentação para entradas grandes, escalando de forma logarítmica ($\mathcal{O}(n \log n)$).

A principal compensação (*trade-off*) é que o algoritmo é mais especializado do que uma ordenação geral baseada em comparações, mas é altamente eficiente para este problema específico.

#### Por que essa combinação de métodos?

O projeto foi concebido para ser prático e eficiente:

- Entradas muito pequenas são processadas por lógica personalizada direta

- Entradas de tamanho médio utilizam uma estratégia equilibrada

- Pilhas grandes ou altamente desordenadas utilizam organização baseada em*radix*.
  
Essa é uma estratégia comum na otimização de algoritmos: utilizar o método mais simples e de menor custo para as entradas menores, e empregar métodos mais estruturados apenas quando estes proporcionam benefícios mensuráveis.

## Estrutura do Projeto

O código-fonte está modularizado em pastas lógicas dentro de srcs/ para garantir a organização e o respeito às normas da 42:

srcs/main.c — Orquestração principal, inicialização de configurações e fluxo de execução.

srcs/parsing/ — Módulo de tratamento de argumentos e entrada:

parsing.c — Função principal de leitura e validação dos argumentos.

parsing_utils.c — Tratamento de flags (--bench, --adaptive, etc.), verificação de dígitos e duplicatas (ft_has_duplicates).

stack_utils.c — Criação, alocação e gerenciamento dos nós da pilha duplamente encadeada.

error.c — Gestão centralizada de erros e liberação segura de memória (ft_error_exit).

srcs/algorithms/ — Módulo de estratégias e ordenação:

compute_disorder.c — Algoritmo para calcular a taxa de desordem da pilha.

strategy.c — Seletor da estratégia ideal com base no tamanho e desordem.

index.c — Normalização e indexação dos valores da pilha.

simple_sorted.c / bubble_sort.c — Algoritmos para coleções pequenas.

bucket_sort.c — Abordagem otimizada para o nível intermediário.

radix_sort.c — Implementação do Radix Sort bit a bit para pilhas complexas.

srcs/bench/ — Módulo de métricas de desempenho:

bench_utils.c — Funções responsáveis por formatar e direcionar os dados de benchmark para a stderr.

srcs/operations/ — Instruções fundamentais do Push Swap:

push.c — Movimentos pa e pb.

swap.c — Movimentos sa, sb e ss.

rotate.c — Movimentos ra, rb e rr.

reverse_rotate.c — Movimentos rra, rrb e rrr.

includes/push_swap.h — Arquivo de cabeçalho unificado com estruturas, protótipos e macros.

Makefile — Automação de compilação robusta com suporte a all, clean, fclean, re e prevenção de relink desnecessário.

### Recursos
#### Material de referência
- Enunciado do projeto Push Swap da 42
- Wikipedia: Radix Sort
- GeeksforGeeks: Radix Sort
- Referências sobre algoritmos de ordenação e explicações sobre ordenação bitwise
- Documentações sobre manipulação de pilhas e complexidade algorítmica

### Fluxo de trabalho assistido por IA
IA utilizada na elaboração deste arquivo README.md

### Exemplo de uso 

``` C
make
```
```
./push_swap --medium 7 3 1 8 2 6 4 5
```
Isso exibe a sequência de operações de pilha necessárias para ordenar a entrada. A saída exata depende do algoritmo escolhido e da ordem dos dados de entrada.

### Exemplo de uso com Benchmark

``` C
./push_swap --bench 7 3 1 8 2 6 4 5
```

Isso exibe a sequência de operações de pilha necessárias para ordenar a entrada na saída padrão (stdout) e registra todas as métricas detalhadas de desordem e contagem de operações na saída de erro padrão (stderr).

### Conclusão
O **Push Swap** é um projeto que combina manipulação de estruturas de dados, raciocínio algorítmico e otimização de performance. Esta implementação busca manter a legibilidade, o rigor técnico com as normas da 42 e a alta eficiência ao selecionar dinamicamente a melhor estratégia para cada cenário de entrada.