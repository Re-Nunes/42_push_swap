/* srcs/algorithms/bucket_sort.c */
#include "../../includes/push_swap.h"

static int	ft_find_max_pos(t_node *b)
{
	t_node	*tmp;
	int		max_index;
	int		max_pos;
	int		pos;

	tmp = b;
	max_index = -1;
	max_pos = 0;
	pos = 0;
	while (tmp)
	{
		if (tmp->index > max_index)
		{
			max_index = tmp->index;
			max_pos = pos;
		}
		tmp = tmp->next;
		pos++;
	}
	return (max_pos);
}

static void	ft_push_chunks(t_node **a, t_node **b, t_config *config, int size)
{
	int	i;
	int	chunk_size;

	i = 0;
	if (size <= 100)
		chunk_size = size / 5;
	else
		chunk_size = size / 12;
	while (*a)
	{
		if ((*a)->index <= i)
		{
			ft_pb(a, b, config);
			ft_rb(b, config);
			i++;
		}
		else if ((*a)->index <= i + chunk_size)
		{
			ft_pb(a, b, config);
			i++;
		}
		else
			ft_ra(a, config);
	}
}

static void	ft_rotate_b_to_top(t_node **b, t_config *config, int max_pos, int size)
{
	if (max_pos <= size / 2)
	{
		while (max_pos > 0)
		{
			ft_rb(b, config);
			max_pos--;
		}
	}
	else
	{
		while (max_pos < size)
		{
			ft_rrb(b, config);
			max_pos++;
		}
	}
}

static void	ft_push_back_loop(t_node **a, t_node **b, t_config *config)
{
	int	b_size;
	int	max_pos;

	while (*b)
	{
		b_size = ft_node_size(*b);
		max_pos = ft_find_max_pos(*b);
		ft_rotate_b_to_top(b, config, max_pos, b_size);
		ft_pa(a, b, config);
	}
}

void	ft_bucket_sort(t_node **a, t_node **b, t_config *config)
{
	int	size;

	if (!a || !*a)
		return ;
	size = ft_node_size(*a);
	if (size <= 3)
	{
		simple_sort(a, b, config);
		return ;
	}
	ft_push_chunks(a, b, config, size);
	ft_push_back_loop(a, b, config);
}