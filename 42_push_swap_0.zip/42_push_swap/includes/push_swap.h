#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include "../libft/libft.h"

// Estrutura para os nós da pilha
typedef struct s_node
{
	int				value;
	struct s_node	*next;
	struct s_node	*prev;
}	t_node;


typedef struct s_stack
{
    t_node  *top;
    t_node  *bottom;
    int     size;
}   t_stack;


// Estrutura para configurar o estado do programa
typedef struct s_config
{
	int	has_bench;
	int	strategy; // 0=Simple, 1=Medium, 2=Complex, 3=Adaptive
	struct {
		int sa; int sb; int ss;
		int pa; int pb;
		int ra; int rb; int rr;
		int rra; int rrb; int rrr;
		int total;
	} ops;
}	t_config;

// --- PROTÓTIPOS DAS OPERAÇÕES DO PUSH_SWAP ---
void	ft_sa(t_node **a, t_config *config);
void	ft_sb(t_node **b, t_config *config);
void	ft_ss(t_node **a, t_node **b, t_config *config);
void	ft_pa(t_node **a, t_node **b, t_config *config);
void	ft_pb(t_node **a, t_node **b, t_config *config);
void	ft_ra(t_node **a, t_config *config);
void	ft_rb(t_node **b, t_config *config);
void	ft_rr(t_node **a, t_node **b, t_config *config);
void	ft_rra(t_node **a, t_config *config);
void	ft_rrb(t_node **b, t_config *config);
void	ft_rrr(t_node **a, t_node **b, t_config *config);

// --- PROTÓTIPOS DE PARSING, ESTRATÉGIAS E UTILITÁRIOS ---
void        ft_error_exit(t_node **a, char **split);
void        ft_free_split(char **split);
double      compute_disorder(t_node *a);
void        ft_index_stack(t_node *a);
int         ft_parse_flag(char *arg, t_config *config);
long long   ft_atoll(const char *str, int *error);
int         ft_is_digit_str(char *str);
void        ft_execute_strategy(t_node **a, t_node **b, t_config *config,
	double disorder);

// Protótipos básicos de pilha e nós
t_node     *ft_create_node(int value);
void        ft_add_back(t_node **stack, t_node *new_node);
void        ft_free_stack(t_node **stack);
int	ft_node_size(t_node *lst);

void simple_sort(t_node **a, t_node **b, t_config *config);
void sort_three(t_node **a, t_config *config);
void move_min_to_top(t_node **a, t_config *config);
int is_sorted(t_node *stack);

#endif